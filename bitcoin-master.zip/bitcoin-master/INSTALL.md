Building Bitcoin
================

See doc/build-*.md for instructions on building the various
elements of the Bitcoin Core reference implementation of Bitcoin.
